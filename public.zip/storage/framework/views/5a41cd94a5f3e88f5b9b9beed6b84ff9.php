<?php echo $__env->make("admin.sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="products-catagories-area clearfix">
            <div class="container">

                <div class="row">
                    <div class="col-12">
                        <div style="margin-top: 2em;"></div>
                        <div class="row">

                            <div class="container">
                                <div class="row">
                                    <div class="col-12 col-md-10 hh-grayBox pt45 pb20">
                                        <div class="row justify-content-between">
                                            <?php $__currentLoopData = $meal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($meal-> status == 'ORDERED'): ?>
                                            <div class="order-tracking completed">
                                                <span class="is-complete"></span>
                                                <p>Ordered<br>
                                            </div>
                                            <div class="order-tracking">
                                                <span class="is-complete"></span>
                                                <p>Shipped<br>
                                            </div>
                                            <div class="order-tracking">
                                                <span class="is-complete"></span>
                                                <p>Delivered</p>
                                            </div>
                                        </div>
                                        <?php elseif($meal->status == 'SHIPPING'): ?>
                                        <div class="order-tracking completed">
                                            <span class="is-complete"></span>
                                            <p>Ordered</p>
                                        </div>
                                        <div class="order-tracking completed">
                                            <span class="is-complete"></span>
                                            <p>Shipped</p>
                                        </div>
                                        <div class="order-tracking">
                                            <span class="is-complete"></span>
                                            <p>Delivered</p>
                                        </div>
                                    </div>
                                    <?php elseif($meal->status == 'DELIVERED'): ?>
                                    <div class="order-tracking completed">
                                        <span class="is-complete"></span>
                                        <p>Ordered</p>
                                    </div>
                                    <div class="order-tracking completed">
                                        <span class="is-complete"></span>
                                        <p>Shipped
                                    </div>
                                    <div class="order-tracking completed">
                                        <span class="is-complete"></span>
                                        <p>Delivered</p>
                                    </div>
                                </div>
                                <?php endif; ?>



                                <div style="margin-top: 4em;"></div>
                                <div class="user-avatar-address">



                                    <p class="border-bottom pb-3">
                                        <span class="d-xl-inline-block d-block mb-2"><i class="fa fa-map-marker mr-2 text-primary "></i><?php echo e($meal-> address); ?></span>
                                        <span class="mb-2 ml-xl-4 d-xl-inline-block d-block"><i class="fa fa-clock-o mr-2 text-danger "></i>Ordered date: <?php echo e($meal-> created_at); ?> </span>
                                        <span class=" mb-2 d-xl-inline-block d-block ml-xl-4 ">STATUS: <?php echo e($meal-> status); ?>

                                        </span>
                                        <span class=" mb-2 d-xl-inline-block d-block ml-xl-4"><i class="fa fa-credit-card mr-2 text-primary "></i>Amount Paid : £ <?php echo e($meal-> price); ?>

                                        </span> <span class=" mb-2 d-xl-inline-block d-block ml-xl-4"><i class="fa fa-truck mr-2 text-primary "></i>Type : <?php echo e($meal-> paymenttype); ?>

                                        </span>
                                    </p>


                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <div class="row">
                                        <div class="col-12 col-md-4">
                                            <h6 class="text-muted">Order</h6>
                                            <ul style="text-align: center;">
                                                <?php $__currentLoopData = $foods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foods): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li> <span><?php echo e($foods->qty); ?></span> Plate <?php if($foods->qty > 1): ?>s <?php else: ?> <?php endif; ?> <span> <?php echo e($foods->meal); ?> </span></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    </div>
    </div>
    </div>
    </div>

    <div style="margin-top: 4em;"></div>

    <!-- ##### jQuery (Necessary for All JavaScript Plugins) ##### -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- Plugins js -->
    <script src="js/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>

</body>

</html>
<?php /**PATH C:\Users\hp\Documents\project\bukka\resources\views/order-tracking.blade.php ENDPATH**/ ?>