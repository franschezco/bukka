<?php echo $__env->make("admin.sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container table-responsive py-5">
    <table class="table table-bordered table-hover">
        <thead class="thead bg-warning">
            <tr>
                <th scope="col">#</th>
                <th scope="col">Customer Name</th>
                <th scope="col">Order Details</th>
                <th scope="col">Price</th>
                <th scope="col">Mode</th>
                <th scope="col">Status</th>
                <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
    <?php $__empty_1 = true; $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr>
        <th scope="row"><?php echo e($key + 1); ?></th>
        <td><?php echo e($order->name); ?></td>
        <td><?php echo e($order->meal); ?> (x<?php echo e($order->qty); ?>)</td>
        <td>£ <?php echo e(number_format($order->price, 2)); ?></td>
        <td><?php echo e($order->paymenttype); ?></td>
        <td><span class="badge badge-success"><?php echo e($order->status); ?></span></td>
        <td>
            <a href="<?php echo e(url('/deleteorder', $order->id)); ?>">
                <button type="button" class="btn-sm btn-danger">Delete <i class="fa fa-trash"></i></button>
            </a>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr>
        <td colspan="6" class="text-center">No orders found.</td>
    </tr>
    <?php endif; ?>
</tbody>


    </table>
</div>
<?php echo $__env->make("admin.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH C:\Users\hp\Documents\project\bukka\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>