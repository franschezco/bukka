<!DOCTYPE html>
<html lang="en">
<head>
    <title>Payment Gateway</title>
</head>
<body>
    <h1>Redirecting to Payment Gateway...</h1>
    <!-- Example for Flutterwave -->
    <script>
        setTimeout(() => {
            window.location.href = "https://flutterwave.com/pay"; // Example URL
        }, 3000);
    </script>
</body>
</html>