@include("header")
@include("sidebar")



        <div class="page-wrapper">

            <div class="page-breadcrumb">
                <div class="row align-items-center">
                    <div class="col-6">

                        <h1 class="mb-0 fw-bold">Dashboard</h1>
                    </div>

                </div>
            </div>
            
            <div class="container-fluid">




            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- footer -->
            <!-- ============================================================== -->
            <footer class="footer text-center">
                All Rights Reserved by Flexy Admin. Designed and Developed by <a
                    href="https://www.wrappixel.com">WrapPixel</a>.
            </footer>
            <!-- ============================================================== -->
            <!-- End footer -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="../client/assets/libs/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="../client/assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../client/dist/js/app-style-switcher.js"></script>
    <!--Wave Effects -->
    <script src="../client/dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="../client/dist/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="../client/dist/js/custom.js"></script>
    <!--This page JavaScript -->
    <!--chartis chart-->
    <script src="../client/assets/libs/chartist/dist/chartist.min.js"></script>
    <script src="../client/assets/libs/chartist-plugin-tooltips/dist/chartist-plugin-tooltip.min.js"></script>
    <script src="../client/dist/js/pages/dashboards/dashboard1.js"></script>
</body>

</html>
