
      <!-- partial:partials/_sidebar.html -->
      <nav class="sidebar sidebar-offcanvas" id="sidebar">

        <ul class="nav">
          


          <li class="nav-item">
            <a class="nav-link" href="{{url('/redirects')}}">
              <i class="icon-file menu-icon"></i>
              <span class="menu-title">Orders</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="{{url('/users')}}">
              <i class="icon-pie-graph menu-icon"></i>
              <span class="menu-title">Users</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="{{url('/foods')}}">
              <i class="icon-command menu-icon"></i>
              <span class="menu-title">Food Menu</span>
            </a>
          </li>
         
          
         
          <li class="nav-item">
            <a class="nav-link" href="{{url('logout')}}">
              <i class="icon-book menu-icon"></i>
              <span class="menu-title">LogOut</span>
            </a>
          </li>
        </ul>
      </nav>
